package com.colabuco.aprendendospring;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ColabucoApplication {

	public static void main(String[] args) {
		SpringApplication.run(ColabucoApplication.class, args);
	}

}
