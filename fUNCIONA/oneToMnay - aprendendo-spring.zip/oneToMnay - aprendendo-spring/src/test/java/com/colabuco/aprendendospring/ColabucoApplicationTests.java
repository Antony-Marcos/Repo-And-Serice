package com.colabuco.aprendendospring;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ColabucoApplicationTests {

	@Test
	void contextLoads() {
	}

}
